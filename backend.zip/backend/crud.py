def create_function():
    return "Function created"
