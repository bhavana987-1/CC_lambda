# Program to multiply two numbers with user input

# Taking input from the user
num1 = int(input("Enter the first number: "))
num2 = int(input("Enter the second number: "))

# Calculating the result
result = num1 * num2

# Displaying the result
print("Multiplication Result:", result)
