# from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException, Header

# from sqlalchemy.orm import Session
# from pydantic import BaseModel
# from typing import Dict
# from time import time
# import os
# import uuid
# import subprocess
# import json
# from .models import Function, ExecutionMetrics
# from .database import SessionLocal, engine


# from fastapi import FastAPI

# app = FastAPI()

# @app.get("/")
# def read_root():
#     return {"Hello": "World"}

# from starlette.middleware.base import BaseHTTPMiddleware

# from models import Function, ExecutionMetrics
# from database import SessionLocal
# from database import engine
# import models

# models.Base.metadata.create_all(bind=engine)

# # ------------------ Configs ------------------
# FUNCTIONS_DIR = "functions"
# os.makedirs(FUNCTIONS_DIR, exist_ok=True)

# # ------------------ Middleware ------------------
# class MetricsMiddleware(BaseHTTPMiddleware):
#     async def dispatch(self, request, call_next):
#         start_time = time()
#         response = await call_next(request)
#         duration = time() - start_time

#         path = request.url.path
#         method = request.method
#         print(f"[METRIC] {method} {path} took {duration:.4f}s")
#         return response

# # ------------------ FastAPI App Init ------------------
# app = FastAPI()
# app.add_middleware(MetricsMiddleware)

# # ------------------ Auth ------------------
# def get_current_user(authorization: str = Header(...)):
#     if authorization != "Bearer super-secret-token":
#         raise HTTPException(status_code=401, detail="Unauthorized")
#     return "admin"

# @app.post("/token")
# def login(username: str = Form(...), password: str = Form(...)):
#     if username == "admin" and password == "password":
#         return {"access_token": "super-secret-token", "token_type": "bearer"}
#     raise HTTPException(status_code=400, detail="Invalid credentials")

# # ------------------ Helper Functions ------------------
# def run_in_docker(file_path):
#     cmd = [
#         "docker", "run", "--rm",
#         "-v", f"{os.path.abspath(file_path)}:/app/script.py",
#         "python:3.9", "python", "/app/script.py"
#     ]
#     result = subprocess.run(cmd, capture_output=True, text=True)
#     return {"output": result.stdout.strip() or result.stderr.strip()}

# def run_in_gvisor(file_path):
#     cmd = [
#         "docker", "run", "--rm",
#         "--runtime=runsc",
#         "-v", f"{os.path.abspath(file_path)}:/app/script.py",
#         "python:3.9", "python", "/app/script.py"
#     ]
#     try:
#         result = subprocess.run(cmd, capture_output=True, text=True)
#         return {"output": result.stdout.strip() or result.stderr.strip()}
#     except Exception as e:
#         return {"error": str(e)}

# # ------------------ Routes ------------------
# @app.get("/")
# def read_root():
#     return {"message": "API is working!"}


# @app.post("/deploy")
# async def deploy_function(
#     name: str = Form(...),
#     language: str = Form(...),
#     timeout: float = Form(...),
#     virtualization_type: str = Form(...),
#     file: UploadFile = File(...),
#     user: str = Depends(get_current_user)
# ):
#     db: Session = SessionLocal()

#     if virtualization_type not in ["docker", "gvisor"]:
#         raise HTTPException(status_code=400, detail="Unsupported runtime. Use docker or gvisor.")

#     ext = ".py" if language == "python" else ".js"
#     func_id = str(uuid.uuid4())
#     file_name = f"{func_id}_{name}{ext}"
#     file_path = os.path.join(FUNCTIONS_DIR, file_name)

#     with open(file_path, "wb") as f:
#         f.write(await file.read())

#     new_func = Function(
#         name=name,
#         code=file_name,
#         language=language,
#         timeout=timeout,
#         virtualization_type=virtualization_type
#     )
#     db.add(new_func)
#     db.commit()
#     db.refresh(new_func)
#     db.close()

#     return {"message": f"Function '{name}' deployed successfully!", "function_id": new_func.id}

# @app.get("/functions")
# def list_functions(user: str = Depends(get_current_user)):
#     db: Session = SessionLocal()
#     functions = db.query(Function).all()
#     db.close()
#     return {"functions": [f.__dict__ for f in functions]}

# @app.post("/execute")
# def execute_function(name: str = Form(...), user: str = Depends(get_current_user)):
#     db: Session = SessionLocal()

#     func = db.query(Function).filter(Function.name == name).first()
#     if not func:
#         db.close()
#         raise HTTPException(status_code=404, detail="Function not found")

#     file_path = os.path.join(FUNCTIONS_DIR, func.code)

#     # Start execution tracking
#     start = time()
#     try:
#         if func.virtualization_type == "docker":
#             result = run_in_docker(file_path)
#         elif func.virtualization_type == "gvisor":
#             result = run_in_gvisor(file_path)
#         else:
#             result = {"error": "Unsupported runtime"}

#         error = None if "error" not in result else result["error"]
#     except Exception as e:
#         result = {"error": str(e)}
#         error = str(e)

#     duration = time() - start

#     metric = ExecutionMetrics(
#         function_id=func.id,
#         exec_time=duration,
#         error=error
#     )
#     db.add(metric)
#     db.commit()
#     db.close()

#     return result

# @app.get("/metrics")
# def get_metrics(user: str = Depends(get_current_user)):
#     db: Session = SessionLocal()
#     metrics = db.query(ExecutionMetrics).all()
#     db.close()
#     return {"metrics": [m.__dict__ for m in metrics]}


from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException, Header
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Dict
from time import time
import os
import uuid
import subprocess
from .models import Function, ExecutionMetrics
from .database import SessionLocal, engine
from starlette.middleware.base import BaseHTTPMiddleware

# ------------------ FastAPI App Init ------------------
app = FastAPI()

# ------------------ Configs ------------------
FUNCTIONS_DIR = "functions"
os.makedirs(FUNCTIONS_DIR, exist_ok=True)

# ------------------ Middleware ------------------
class MetricsMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        start_time = time()
        response = await call_next(request)
        duration = time() - start_time

        path = request.url.path
        method = request.method
        print(f"[METRIC] {method} {path} took {duration:.4f}s")
        return response

app.add_middleware(MetricsMiddleware)

# ------------------ Auth ------------------
def get_current_user(authorization: str = Header(...)):
    if authorization != "Bearer super-secret-token":
        raise HTTPException(status_code=401, detail="Unauthorized")
    return "admin"

@app.post("/token")
def login(username: str = Form(...), password: str = Form(...)):
    if username == "admin" and password == "password":
        return {"access_token": "super-secret-token", "token_type": "bearer"}
    raise HTTPException(status_code=400, detail="Invalid credentials")

# ------------------ Helper Functions ------------------
def run_in_docker(file_path):
    cmd = [
        "docker", "run", "--rm",
        "-v", f"{os.path.abspath(file_path)}:/app/script.py",
        "python:3.9", "python", "/app/script.py"
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return {"output": result.stdout.strip() or result.stderr.strip()}

def run_in_gvisor(file_path):
    cmd = [
        "docker", "run", "--rm",
        "--runtime=runsc",
        "-v", f"{os.path.abspath(file_path)}:/app/script.py",
        "python:3.9", "python", "/app/script.py"
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        return {"output": result.stdout.strip() or result.stderr.strip()}
    except Exception as e:
        return {"error": str(e)}

# ------------------ Routes ------------------
@app.get("/")
def read_root():
    return {"message": "API is working!"}

@app.post("/deploy")
async def deploy_function(
    name: str = Form(...),
    language: str = Form(...),
    timeout: float = Form(...),
    virtualization_type: str = Form(...),
    file: UploadFile = File(...),
    user: str = Depends(get_current_user)
):
    db: Session = SessionLocal()

    if virtualization_type not in ["docker", "gvisor"]:
        raise HTTPException(status_code=400, detail="Unsupported runtime. Use docker or gvisor.")

    ext = ".py" if language == "python" else ".js"
    func_id = str(uuid.uuid4())
    file_name = f"{func_id}_{name}{ext}"
    file_path = os.path.join(FUNCTIONS_DIR, file_name)

    with open(file_path, "wb") as f:
        f.write(await file.read())

    new_func = Function(
        name=name,
        code=file_name,
        language=language,
        timeout=timeout,
        virtualization_type=virtualization_type
    )
    db.add(new_func)
    db.commit()
    db.refresh(new_func)
    db.close()

    return {"message": f"Function '{name}' deployed successfully!", "function_id": new_func.id}

@app.get("/functions")
def list_functions(user: str = Depends(get_current_user)):
    db: Session = SessionLocal()
    functions = db.query(Function).all()
    db.close()
    return {"functions": [f.__dict__ for f in functions]}

@app.post("/execute")
def execute_function(name: str = Form(...), user: str = Depends(get_current_user)):
    db: Session = SessionLocal()

    func = db.query(Function).filter(Function.name == name).first()
    if not func:
        db.close()
        raise HTTPException(status_code=404, detail="Function not found")

    file_path = os.path.join(FUNCTIONS_DIR, func.code)

    # Start execution tracking
    start = time()
    try:
        if func.virtualization_type == "docker":
            result = run_in_docker(file_path)
        elif func.virtualization_type == "gvisor":
            result = run_in_gvisor(file_path)
        else:
            result = {"error": "Unsupported runtime"}

        error = None if "error" not in result else result["error"]
    except Exception as e:
        result = {"error": str(e)}
        error = str(e)

    duration = time() - start

    metric = ExecutionMetrics(
        function_id=func.id,
        exec_time=duration,
        error=error
    )
    db.add(metric)
    db.commit()
    db.close()

    return result

@app.get("/metrics")
def get_metrics(user: str = Depends(get_current_user)):
    db: Session = SessionLocal()
    metrics = db.query(ExecutionMetrics).all()
    db.close()
    return {"metrics": [m.__dict__ for m in metrics]}

# ------------------ Models ------------------
# Ensure the database models are created
from .models import Base
Base.metadata.create_all(bind=engine)
