def add(a, b):
    return a + b

if __name__ == "__main__":
    # Example inputs (you can modify these or pass via input() if needed)
    num1 = 5
    num2 = 3
    result = add(num1, num2)
    print(f"The sum of {num1} and {num2} is: {result}")
