# Program to multiply two numbers with hardcoded values

num1 = 8
num2 = 9

result = num1 * num2

print("Multiplication Result:", result)
