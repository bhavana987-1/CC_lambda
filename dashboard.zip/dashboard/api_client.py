import requests

# Change this if your backend runs somewhere else!
BASE_URL = "http://localhost:8000"

def list_functions():
    response = requests.get(f"{BASE_URL}/functions")
    response.raise_for_status()  # will throw error if response not 200 OK
    return response.json()
